PERSONAL AI KNOWLEDGE MANAGER BOT

A production-ready Telegram Bot built with Python 3.11 and aiogram 3.x to help users convert unstructured messages and scattered links into organized markdown notes.

FEATURES

1. Markdown Formatting: Automatically parses incoming URLs, code snippets, and text into structured markdown blocks.
2. Search Functionality: Perform keyword search across saved notes.
3. Daily Summaries: Generates daily compilation reports of all stored items.
4. Local Persistence: Light database storage using aiosqlite.

LOCAL SETUP

1. Clone or download this repository.
2. Create a virtual environment:
   python -m venv venv
   source venv/bin/activate  (On Windows use: venv\Scripts\activate)
3. Install dependencies:
   pip install -r requirements.txt
4. Copy env example and configure token:
   cp .env.example .env
   Set BOT_TOKEN in your .env file.
5. Run the bot:
   python main.py

DEPLOYMENT GUIDE (RENDER)

1. Push code to your GitHub repository.
2. Create a new Background Worker service on Render.
3. Connect your repository.
4. Set build command to: pip install -r requirements.txt
5. Set start command to: python main.py
6. Add Environment Variable BOT_TOKEN with your Telegram API key.
7. Deploy service.
